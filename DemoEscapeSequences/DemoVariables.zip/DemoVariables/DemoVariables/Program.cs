﻿using static System.Console;
class DemoVariables
{
    static void Main()
    {
        int anInt = -123;
        uint anUnsignedInt = 567;
        WriteLine("The int is {0} and the unsigned int is {1}.",
                   anInt, anUnsignedInt);
    }
}